# J.A.R.V.I.S — Android Sürümü

Bu klasör, masaüstü (Windows/Mac) JARVIS Python asistanının **Android uygulaması** olarak
yeniden yazılmış halidir. Kotlin + Android Studio ile derlenir, Gemini API'yi
function-calling (araç çağırma) ile kullanır — masaüstü sürümdeki mantığın aynısı.

## Kurulum (Android Studio)

1. **Android Studio**'yu aç (yoksa https://developer.android.com/studio adresinden indir).
2. `File → Open` ile bu `JarvisAndroid` klasörünü seç.
3. Gradle senkronizasyonu bitene kadar bekle (ilk açılışta internet ister, bağımlılıkları indirir).
4. Telefonunu USB ile bağla (Geliştirici Seçenekleri → USB Hata Ayıklama açık) veya bir emülatör oluştur.
5. Üstteki ▶️ (Run) butonuna bas.
6. Uygulama ilk açıldığında senden xAI (Grok) API anahtarı ister:
   - https://console.x.ai → API Keys → yeni anahtar oluştur
   - Anahtarı kopyala, uygulamaya yapıştır, kaydet.
   - Not: xAI API'si kullanım bazlı ücretlendirilir (genelde yeni hesaplara bir miktar ücretsiz kredi tanımlanır); Gemini'nin çok düşük günlük ücretsiz limitine göre çok daha esnektir.

Derlemek için internet ve JDK 17 gerekir (Android Studio bunu genelde otomatik indirir).

## Neler Aynı Şekilde Çalışıyor

| Özellik | Nasıl |
|---|---|
| Sesli/yazılı AI sohbet (Grok) | `GrokClient` — xAI'nin OpenAI-uyumlu function calling API'si ile masaüstündeki `main.py` mantığının aynısı |
| Uygulama açma | `AppLauncher` — yüklü uygulamalar arasında isimle arar, `PackageManager` ile açar |
| Hava durumu | `WeatherActions` — Open-Meteo (ücretsiz, API anahtarı gerekmez) |
| Sistem bilgisi (pil, RAM, depolama, saat) | `SystemInfoActions` — `BatteryManager`/`ActivityManager`/`StatFs` |
| Tarayıcı arama / URL açma | `BrowserActions` — `Intent.ACTION_VIEW` |
| YouTube / Spotify oynatma | `MediaActions` — uygulama varsa direkt açar, yoksa tarayıcıya düşer |
| WhatsApp mesajı | `WhatsAppActions` — `wa.me` linkiyle mesaj hazırlar (Android'de 3. parti uygulamalar mesajı **otomatik gönderemez**, kullanıcı dokunup göndermeli — bu bir Android/WhatsApp kısıtı) |
| Takvim & Hatırlatıcı | `CalendarActions` — Android Takvim sağlayıcısı (`CalendarContract`); hatırlatıcılar ⏰ önekiyle aynı takvime yazılır |
| Bellek (hatırlama) | `MemoryManager` — cihaz içinde JSON dosyası olarak saklanır |
| Sesli komut / TTS | `SpeechManager` — Android'in yerleşik `SpeechRecognizer` ve `TextToSpeech` API'leri |

## Bilerek Çıkarılan / Basitleştirilen Özellikler

Bunlar bilgisayara özel olduğu veya Android'de güvenlik/izin modeliyle
uyuşmadığı için bu sürüme **dahil edilmedi**:

- **Ekran analizi (`analyze_screen`)** — macOS/Windows'ta ekran görüntüsü alıp
  Gemini Vision'a gönderiyordu. Android'de bu, `MediaProjection` API'siyle
  kullanıcıdan her seferinde ekstra bir ekran kaydı izni ister; istersen ayrı
  bir adımda ekleyebiliriz.
- **Terminal komutu çalıştırma (`shell_run`)** — Android uygulamaları
  sandbox içinde çalışır, işletim sistemi düzeyinde komut çalıştırmaya
  izin vermez (ve bu zaten güvenlik açısından riskli bir özellikti).
- **Apple Takvim/Hatırlatıcılar/Music, iPhone Sağlık verisi** — bunlar zaten
  yalnızca macOS'a özeldi; Android'de karşılığı yok, en yakın eşdeğerleri
  (Android Takvim) kullanıldı.
- **YouTube kanal istatistikleri** — dahil edilmedi ama `youtube_stats.py`
  mantığı aynı şekilde bir Android aracı olarak eklenebilir.

## Klasör Yapısı

```
app/src/main/java/com/jarvis/assistant/
  ai/            Gemini istemcisi ve araç (tool) tanımları
  actions/       Her özelliğin Android karşılığı (open_app, weather, whatsapp, ...)
  core/          Sohbet UI mantığı, komut yönlendirme, ayarlar
  memory/        Kalıcı hafıza (JSON tabanlı)
  voice/         Sesli komut + sesli yanıt
  ui/            API anahtarı kurulum ekranı
```

## Notlar

- `minSdk = 26` (Android 8.0+) — güncel telefonların büyük çoğunluğunu kapsar.
- İlk çalıştırmada mikrofon, takvim ve rehber izinleri istenir.
- WhatsApp, Spotify, YouTube gibi uygulamalar telefonda yüklü değilse otomatik
  olarak tarayıcı sürümüne yönlendirilir.
