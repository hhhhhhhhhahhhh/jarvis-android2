package com.jarvis.assistant.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import java.io.File

/**
 * WhatsApp is only reachable through its own Intent API on Android — there is
 * no "desktop vs web" distinction like on macOS/Windows. We open a chat with a
 * pre-filled message; the user still has to tap send (WhatsApp does not allow
 * silently sending messages from third-party apps for spam-prevention reasons).
 */
object WhatsAppActions {

    private fun contactsFile(context: Context) = File(context.filesDir, "phone_book.json")

    fun saveContact(context: Context, name: String, phone: String) {
        val file = contactsFile(context)
        val obj = if (file.exists()) JSONObject(file.readText()) else JSONObject()
        obj.put(name.lowercase(), phone)
        file.writeText(obj.toString(2))
    }

    fun lookupContact(context: Context, name: String): String? {
        val file = contactsFile(context)
        if (!file.exists()) return null
        val obj = JSONObject(file.readText())
        return if (obj.has(name.lowercase())) obj.getString(name.lowercase()) else null
    }

    /**
     * Opens a WhatsApp chat with [phoneOrContactName] and pre-fills [message].
     * If a saved contact name is given instead of a number, it is resolved first.
     */
    fun sendMessage(context: Context, phoneOrContactName: String, message: String): String {
        val resolvedPhone = if (phoneOrContactName.any { it.isDigit() }) {
            phoneOrContactName.filter { it.isDigit() || it == '+' }
        } else {
            lookupContact(context, phoneOrContactName)
                ?: return "\"$phoneOrContactName\" için kayıtlı bir numara bulamadım. Önce kaydet."
        }

        val uri = Uri.parse(
            "https://wa.me/$resolvedPhone?text=${Uri.encode(message)}"
        )
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            "WhatsApp'ta $resolvedPhone için mesaj hazırlandı, göndermek için dokun."
        } catch (e: Exception) {
            "WhatsApp açılamadı: ${e.message}"
        }
    }
}
