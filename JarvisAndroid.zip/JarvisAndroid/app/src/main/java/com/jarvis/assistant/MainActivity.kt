package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.assistant.ai.GeminiClient
import com.jarvis.assistant.core.ActionRouter
import com.jarvis.assistant.core.ChatAdapter
import com.jarvis.assistant.core.ChatMessage
import com.jarvis.assistant.core.Config
import com.jarvis.assistant.core.SystemPrompt
import com.jarvis.assistant.memory.MemoryManager
import com.jarvis.assistant.ui.ApiKeySetupActivity
import com.jarvis.assistant.voice.SpeechManager
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var config: Config
    private lateinit var memory: MemoryManager
    private lateinit var actionRouter: ActionRouter
    private lateinit var geminiClient: GeminiClient
    private lateinit var speechManager: SpeechManager
    private lateinit var adapter: ChatAdapter

    private val messages = mutableListOf<ChatMessage>()

    private val permissionRequestCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        config = Config(this)
        if (!config.hasApiKey) {
            startActivity(Intent(this, ApiKeySetupActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)
        requestRuntimePermissions()

        memory = MemoryManager(this)
        actionRouter = ActionRouter(this, memory)
        geminiClient = GeminiClient(
            apiKey = config.geminiApiKey!!,
            actionRouter = actionRouter,
            systemPrompt = SystemPrompt.build(memory.asContextString())
        )
        speechManager = SpeechManager(this)

        val recycler = findViewById<RecyclerView>(R.id.chatRecycler)
        adapter = ChatAdapter(messages)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        val input = findViewById<EditText>(R.id.messageInput)
        val sendButton = findViewById<ImageButton>(R.id.sendButton)
        val micButton = findViewById<ImageButton>(R.id.micButton)

        addMessage("Merhaba! Ben JARVIS. Nasıl yardımcı olabilirim?", isUser = false)

        sendButton.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                handleUserMessage(text)
            }
        }

        micButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestRuntimePermissions()
                return@setOnClickListener
            }
            speechManager.startListening(
                onResult = { text -> handleUserMessage(text) },
                onError = { err -> addMessage(err, isUser = false) }
            )
        }
    }

    private fun handleUserMessage(text: String) {
        addMessage(text, isUser = true)
        lifecycleScope.launch {
            val reply = geminiClient.send(text)
            addMessage(reply, isUser = false)
            speechManager.speak(reply)
        }
    }

    private fun addMessage(text: String, isUser: Boolean) {
        adapter.addMessage(ChatMessage(text, isUser))
        findViewById<RecyclerView>(R.id.chatRecycler).scrollToPosition(messages.size - 1)
    }

    private fun requestRuntimePermissions() {
        val needed = listOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.READ_CONTACTS
        ).filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), permissionRequestCode)
        }
    }

    override fun onDestroy() {
        speechManager.destroy()
        super.onDestroy()
    }
}
