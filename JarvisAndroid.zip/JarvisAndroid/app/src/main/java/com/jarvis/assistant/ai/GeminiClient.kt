package com.jarvis.assistant.ai

import com.jarvis.assistant.core.ActionRouter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Talks to the Gemini API's generateContent endpoint using function calling,
 * the same pattern main.py uses on desktop (tool declarations + a dispatch loop),
 * except tool execution happens through ActionRouter against Android APIs.
 */
class GeminiClient(
    private val apiKey: String,
    private val actionRouter: ActionRouter,
    private val systemPrompt: String
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val model = "gemini-2.5-flash"
    private val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"

    /** Full running conversation, in Gemini's "contents" format. */
    private val history = JSONArray()

    suspend fun send(userText: String): String = withContext(Dispatchers.IO) {
        history.put(userTurn(userText))

        repeat(MAX_TOOL_HOPS) {
            val response = callApi()
            val candidate = response.optJSONArray("candidates")?.optJSONObject(0)
                ?: return@withContext "Gemini'den yanıt alınamadı."

            val parts = candidate.getJSONObject("content").getJSONArray("parts")
            val functionCalls = mutableListOf<JSONObject>()
            val textBuilder = StringBuilder()

            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                if (part.has("functionCall")) {
                    functionCalls.add(part.getJSONObject("functionCall"))
                } else if (part.has("text")) {
                    textBuilder.append(part.getString("text"))
                }
            }

            // Record the model's turn (including any function calls) in history.
            history.put(JSONObject().put("role", "model").put("parts", parts))

            if (functionCalls.isEmpty()) {
                return@withContext textBuilder.toString().ifBlank { "..." }
            }

            // Execute every requested tool call and feed results back in one turn.
            val responseParts = JSONArray()
            for (call in functionCalls) {
                val fnName = call.getString("name")
                val args = call.optJSONObject("args") ?: JSONObject()
                val result = actionRouter.execute(fnName, args)
                responseParts.put(
                    JSONObject().put(
                        "functionResponse",
                        JSONObject()
                            .put("name", fnName)
                            .put("response", JSONObject().put("result", result))
                    )
                )
            }
            history.put(JSONObject().put("role", "user").put("parts", responseParts))
        }

        "İşlemi tamamlayamadım, tekrar dener misin?"
    }

    private fun callApi(): JSONObject {
        val body = JSONObject().apply {
            put("contents", history)
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            put("tools", JSONArray().put(JSONObject().put("functionDeclarations", ToolDeclarations.all)))
        }

        val request = Request.Builder()
            .url("$endpoint?key=$apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                return JSONObject().put(
                    "candidates",
                    JSONArray().put(
                        JSONObject().put(
                            "content",
                            JSONObject().put(
                                "parts",
                                JSONArray().put(JSONObject().put("text", "API hatası (${resp.code}): $text"))
                            )
                        )
                    )
                )
            }
            return JSONObject(text)
        }
    }

    private fun userTurn(text: String) = JSONObject()
        .put("role", "user")
        .put("parts", JSONArray().put(JSONObject().put("text", text)))

    companion object {
        private const val MAX_TOOL_HOPS = 5
    }
}
