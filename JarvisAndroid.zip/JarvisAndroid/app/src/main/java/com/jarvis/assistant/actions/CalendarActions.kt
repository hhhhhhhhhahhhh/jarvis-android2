package com.jarvis.assistant.actions

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.provider.CalendarContract
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Android has no direct equivalent of "Apple Reminders" — the closest system-level
 * API is the Calendar Provider, so reminders are stored as all-day-less calendar
 * events with a title prefix, and real calendar events use the same provider.
 */
object CalendarActions {

    private val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())

    private fun defaultCalendarId(context: Context): Long? {
        val cursor = context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY),
            null, null, null
        ) ?: return null
        var id: Long? = null
        cursor.use {
            while (it.moveToNext()) {
                id = it.getLong(0)
                if (it.getInt(1) == 1) break // prefer primary calendar
            }
        }
        return id
    }

    fun addEvent(context: Context, title: String, startIso: String, endIso: String? = null): String {
        val calId = defaultCalendarId(context) ?: return "Takvim bulunamadı. Bir hesap ekli mi kontrol et."
        val start = parseIso(startIso) ?: return "Tarih anlaşılamadı: $startIso"
        val end = endIso?.let { parseIso(it) } ?: (start + 60 * 60 * 1000)

        val values = ContentValues().apply {
            put(CalendarContract.Events.DTSTART, start)
            put(CalendarContract.Events.DTEND, end)
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.CALENDAR_ID, calId)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        }
        val uri = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
        return if (uri != null) "\"$title\" takvime eklendi." else "Etkinlik eklenemedi."
    }

    fun addReminder(context: Context, title: String, dueIso: String): String {
        // Same provider, tagged with a bell prefix so it reads clearly in any calendar app.
        return addEvent(context, "⏰ $title", dueIso)
    }

    fun deleteEvent(context: Context, title: String): String {
        val cursor = context.contentResolver.query(
            CalendarContract.Events.CONTENT_URI,
            arrayOf(CalendarContract.Events._ID, CalendarContract.Events.TITLE),
            "${CalendarContract.Events.TITLE} LIKE ?",
            arrayOf("%$title%"),
            null
        ) ?: return "Etkinlik aranamadı."

        var deletedAny = false
        cursor.use {
            while (it.moveToNext()) {
                val id = it.getLong(0)
                val uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id)
                context.contentResolver.delete(uri, null, null)
                deletedAny = true
            }
        }
        return if (deletedAny) "\"$title\" ile eşleşen etkinlik(ler) silindi." else "\"$title\" ile eşleşen etkinlik bulunamadı."
    }

    fun listEvents(context: Context, fromMillis: Long, toMillis: Long): String {
        val uri = CalendarContract.Events.CONTENT_URI
        val cursor = context.contentResolver.query(
            uri,
            arrayOf(CalendarContract.Events.TITLE, CalendarContract.Events.DTSTART),
            "${CalendarContract.Events.DTSTART} >= ? AND ${CalendarContract.Events.DTSTART} <= ?",
            arrayOf(fromMillis.toString(), toMillis.toString()),
            "${CalendarContract.Events.DTSTART} ASC"
        ) ?: return "Takvim okunamadı."

        val results = mutableListOf<String>()
        val fmt = SimpleDateFormat("d MMM HH:mm", Locale("tr"))
        cursor.use {
            while (it.moveToNext()) {
                val title = it.getString(0)
                val start = it.getLong(1)
                results.add("${fmt.format(java.util.Date(start))} — $title")
            }
        }
        return if (results.isEmpty()) "Bu aralıkta etkinlik yok." else results.joinToString("\n")
    }

    private fun parseIso(iso: String): Long? {
        return try {
            isoFormat.parse(iso.replace("Z", ""))?.time
        } catch (e: Exception) {
            null
        }
    }
}
